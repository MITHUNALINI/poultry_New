import React, { Component } from "react";
import VerticalTabs from "./VerticalTabs";


class AboutUs extends Component {
  

  render() {
    return (
     <div style={{margin:20,boxShadow:"10px 20px 25px black", border: "2px 5px 8px",height:"3500px"}}>
         <VerticalTabs/> 
     </div>
    );
  }
}

export default AboutUs;