import React, { Component } from "react";
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { Card, CardContent, FormControl, Typography,InputLabel, NativeSelect, FormHelperText } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import AddBoxIcon from '@material-ui/icons/AddBox';
import Button from '@material-ui/core/Button';
import SaveIcon from '@material-ui/icons/Save';
import ReplayIcon from '@material-ui/icons/Replay';
import CancelPresentationIcon from '@material-ui/icons/CancelPresentation';

import './AddUser.Css';

import FormatListBulletedIcon from '@material-ui/icons/FormatListBulleted';





const style = {
  root: {
    minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 50,
    color: '#e0f7fa'
  },
  button: {
    fontSize: '20px'
  },
  formControl: {
   // margin: spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    //marginTop: spacing(2),
  },
}

export default class AddUser extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "",
      email: "",
      Password: "",
      roles: "",
      successful: false
    };
  }

  onChangename = (event) => {
    this.setState({
      name: event.target.value
    });
  }

  onChangeemail = (event) => {
    this.setState({
      email: event.target.value
    });
  }

  onChangepassword = (event) => {
    this.setState({
      Password: event.target.value
    });
  }

  onChangeroles = (event) => {
    this.setState({
      roles: event.target.value
    });
  }
 

  

  handleAddUser = (event) => {
    event.preventDefault();

    if (this.state.name&& this.state.email && this.state.Password && this.state.roles) {
      console.log(this.state.name + " " + this.state.email + " " + this.state.Password + "" +this.state.roles)
      this.setState({
        successful: true,
        message: "Success -AddUser Saved Successfully."
      })
    } else {
      this.setState({
        successful: false,
        message: "Not valied"
      })
    }
  }

  render() {
    return (
      
        <Grid container spacing={1}>
           
        <Grid item xs={4}/>
        <Grid item xs={5} Style={{backgroundColor:"black"}}>
          <Card className={style.root} style={{margin:20,boxShadow:"10px 20px 25px black", border: "2px 5px 8px",marginTop:120}}>
           <CardContent>
           <div className="card">
        <Grid item xs={4}/>
             <form className={style.root} noValidate autoComplete="off" style={{width:'150%'}}onSubmit={this.handleRegister}>
                  {!this.state.successful && (
             <Grid container spacing={1}>
                      <Grid item xs={11}>

                     
                            
                         <h3 style={{fontSize:30,color:"#1a237e"}}>Add  User</h3>
                        
                        
                     
                       
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                            
                        <TextField type="text" id="outlined-required" label="User Name" variant="outlined" helperText="Enter your name" style={{width:"120%"}} onChange={this.onChangename} />
                        </FormControl>&emsp; &emsp; &emsp;  &emsp;  &emsp; 
                        
                        <FormControl>
                            
                            <TextField type="text" id="outlined-required" label="Email" variant="outlined" helperText="Enter Email Address" style={{width:"120%"}} onChange={this.onChangeemail} />
                            </FormControl>
                       &emsp; &emsp;  
                        </Grid>
                         
                        <Grid item xs={12}>
                        <FormControl size="small"onChange={this.onChangeroles}>
                            <InputLabel>Roles</InputLabel>
                            <NativeSelect
                              inputProps={{
                                  name:'Roles',
                                  id: 'Roles',
                                  
                              }}
                            >
                            <option value={"Select Roles"}>Select Roles</option>
                            <option value={"ROLE_USER"}>ROLE_USER</option>
                            <option value={"ROLE_ADMIN"}>ROLE_ADMIN</option>
                            </NativeSelect>
                            <FormHelperText>Please select your Roles</FormHelperText>
                        </FormControl>&emsp; &emsp; 
                       
                        
                      

                      
                        <FormControl>
                        <TextField type="" id="outlined-required" label="Passworld" variant="outlined" helperText="Enter Passworld"  style={{width:"120%"}}onChange={this.onChangepassword} />
                        </FormControl>
                        </Grid>

                        <Grid item xs={12}>
                       
                        <Button href="/Save" variant="contained"onClick={this.handleAddUser} style={{backgroundColor:'#1b5e20',marginLeft:320 }}> <SaveIcon style={{fontSize:20}}/>Add</Button>&emsp; 
                        <Button  href="/Reset"variant="contained" style={{backgroundColor:'#0d47a1'}}> <ReplayIcon style={{fontSize:20}}/>RESET</Button>&emsp;
                        <Button href="/upadate" variant="contained" style={{backgroundColor:'#0d47a1'}}><CancelPresentationIcon style={{fontSize:20}}/>Cencel</Button> 
                       {/* </Paper> */}
                        </Grid>
                 </Grid>   
                 )}
                 {this.state.message && (
               <div>
                 <Typography color='#d50000' variant="overline" display="block" gutterBottom> 
                     <strong>{this.state.message}</strong>
                 </Typography>
               </div>
             )}
              
                </form>
                </div>
                {/* </Paper> */}
              </CardContent>
        </Card>
        </Grid>
        <Grid item xs={4}/>
        
      </Grid>
    //  </div>
      
    );
                            
}
}