import React, { Component } from "react";
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { Card, CardContent, FormControl, Typography,InputLabel, NativeSelect, FormHelperText } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import SaveIcon from '@material-ui/icons/Save';
import ReplayIcon from '@material-ui/icons/Replay';
import './AddUser.Css';
import feedbackService from "../services/feedback.service";
import FeedbackIcon from '@material-ui/icons/Feedback';

const style = {
  root: {
    minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 50,
    color: '#e0f7fa'
  },
  button: {
    fontSize: '20px'
  },
  formControl: {
   // margin: spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    //marginTop: spacing(2),
  },
}

export default class AddFeedback extends Component {
  constructor(props) {
    super(props);

    this.state = {
      userId: "",
      productId: "",
      feedback: "",
      feedbackDate: "",
      successful: false
      
    };
  }

  onChangeuserId = (event) => {
    this.setState({
        userId: event.target.value
    });
  }

  onChangeproductId = (event) => {
    this.setState({
      productId: event.target.value
    });
  }

  onChangefeedback = (event) => {
    this.setState({
        feedback: event.target.value
    });
  }

  componentDidMount(){
    this.reloadFeedbackList();
  }

  reloadFeedbackList = () => {
    feedbackService.getAllFeedback()
       .then((Response) => {
         this.setState({FeedbackArr:Response.data})
       })
  }
  

  handleAddFeedback = (event) => {
    event.preventDefault();
    
    let Feedback = {
      userId :this.state.userId ,
      productId : this.state.productId, 
      feedback : this.state.feedback, 
      
    }
    feedbackService.createFeedback (Feedback)
    console.log("hiiiiiiii")
    console.log (this.state.feedback)
    if (this.state.userId && this.state.productId && this.state.feedback ) {
      console.log(this.state.userId + " " + this.state.productId + " " + this.state.feedback )
      this.setState({
        successful: true,
        message: "Success -AddFeedback Saved Successfully."
      })
    } else {
      this.setState({
        successful: false,
        message: "Not valied"
      })
    }
  }

  render() {
    return (
      //  <div style={{boxShadow:"5px 10px 15px black",padding:"20px",border:"5px solid,black",overflow: "hidden",margin: "30px" }} >
        <Grid container spacing={1}>
           
        <Grid item xs={4}/>
        <Grid item xs={5} Style={{backgroundColor:"black"}}>
          <Card className={style.root} style={{margin:20,boxShadow:"10px 20px 25px black", border: "2px 5px 8px",marginTop:120}}>
           <CardContent>
           {/* <Paper variant="outlined"> */}
           <div className="card">
        <Grid item xs={4}/>
             <form className={style.root} noValidate autoComplete="off" style={{width:'150%'}}onSubmit={this.handleRegister}>
                  {!this.state.successful && (
             <Grid container spacing={1}>
                      <Grid item xs={11}>

                     
                         <h3 style={{fontSize:30,color:"#1a237e"}}>Add  Feedback</h3>
                        
                        
                      {/* <h3 style={{fontSize:30,color:"#1a237e"}}>Add User</h3>
                     */}
                       
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                            
                        <TextField type="" id="outlined-required" label="User Id" variant="outlined" helperText="Enter your uderid" style={{width:"120%"}} onChange={this.onChangeuserId} />
                        </FormControl>&emsp; &emsp; &emsp;  &emsp;  &emsp; 
                        
                        <FormControl>
                            
                            <TextField type="" id="outlined-required" label="Product Id" variant="outlined" helperText="Enter Product Id" style={{width:"120%"}} onChange={this.onChangeproductId} />
                            </FormControl>
                       &emsp; &emsp;  
                        </Grid>
                         
                        <Grid item xs={12}>
                        {/* <FormControl>
                        <TextField type="text" id="outlined-required" label="Address" variant="outlined" helperText="Enter your Address" style={{width:"120%"}} onChange={this.onChangeCoverPhotoURL} />
                        </FormControl>&emsp; &emsp; &emsp;  &emsp;  &emsp;  */}
                      

                      
                        <FormControl>
                        <TextField type="" id="outlined-required" label="Feed Back" variant="outlined" helperText="Enter your feedback"  style={{width:"120%"}}onChange={this.onChangefeedback} />
                        </FormControl>
                        
                        <Button href="/Save" variant="contained"onClick={this.handleAddFeedback} style={{backgroundColor:'#1b5e20',marginLeft:90 }}> <SaveIcon style={{fontSize:20}}/>Add</Button>&emsp; 
                        <Button  href="/Reset"variant="contained" style={{backgroundColor:'#0d47a1'}}> <ReplayIcon style={{fontSize:20}}/>RESET</Button>&emsp;
                        <Button  href="/ViewFeedback"variant="contained" style={{backgroundColor:'#0d47a1'}}> <FeedbackIcon style={{fontSize:20}}/>Feedback List</Button>&emsp;
                       {/* </Paper> */}
                        </Grid>
                 </Grid>   
                 )}
                 {this.state.message && (
               <div>
                 <Typography color='#d50000' variant="overline" display="block" gutterBottom> 
                     <strong>{this.state.message}</strong>
                 </Typography>
               </div>
             )}
              
                </form>
                </div>
                {/* </Paper> */}
              </CardContent>
        </Card>
        </Grid>
        <Grid item xs={4}/>
        
      </Grid>
    //  </div>
      
    );
                            
}
}