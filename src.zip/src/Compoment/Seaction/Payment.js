import React, { Component } from 'react'

export class Payment extends Component {
    render() {
        return (
            <div>
                <h2 style={{textAlign: "center"}}>Payment Component</h2>
            </div>
        )
    }
}

export default Payment

