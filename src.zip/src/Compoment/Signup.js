import React, {Component} from 'react';
import Paper from '@material-ui/core/Paper';
import CardMedia from '@material-ui/core/CardMedia';
import { Card, CardContent, Typography, Grid, FormControl, TextField, Button } from '@material-ui/core';
import pic from './pic.jpg';
// import { Validator } from 'node-input-validator';
import {ValidatorForm, TextValidator} from 'react-material-ui-form-validator';


const style = {
    root:  {
        minWidth: 275,
        //backgroundColor:'white',
       // marginTop: 70,
        color: '#002984',
        
      },
    
}



export default class Signup extends Component {
    constructor(props){
        super(props);

    this.state = {
      username: "",
      password: "",
      email:"",
      confirmpassword:""
    };
  }

  componentDidMount(){
    ValidatorForm.addValidationRule('isName',(value)=> {
      if((this.state.username.length >3) && (this.state.username.length <30)){
        return true;
      }
      return false;
    });
  
  }

  handleUsernameChange = (e) => {
    this.setState({
      username: e.target.value
    });
    // console.log(this.state.username)
  }
  handleEmailChange = (e) => {
    this.setState({
      email: e.target.value
    });
  }
  handlePasswordChange = (e) => {
    this.setState({
      password: e.target.value
    });
  }
  handleConfirmPasswordChange = (e) => {
    this.setState({
      confirmpassword: e.target.value
    });
  }

  
render(){ 
  const {username,password,email,confirmpassword} = this.state;
    return (
      // <div style={{backgroundImage: `url(${picture3})`,backgroundRepeat:"no-repeat",height:"100%",width:"100%",backgroundPosition:'center',backgroundSize:'cover',marginTop:1}}>
        <div>
      <Paper style={{height:800,width:730, borderRadius:50,  backgroundColor:"#e0e0e0",marginLeft:600,border:'1px solid black',boxShadow:"10px 5px 25px",marginTop:75}}>

      <Grid container style={{margin:20}}>
        <Grid item xs={10}/>
        <Grid item xs={10} style={{marginTop:20}}>
        <center>
          <Card style={{height:750,width:670, borderRadius:50,marginLeft:10,marginRight:20,}}>
              <CardContent>
                <Paper style={{ borderRadius:50,height:700, width:370,marginLeft:10}}>
                  <center>
                <h1 style={{color:"blue"}}>Sign Up Now </h1>
                </center>
                <ValidatorForm>
                  <Grid container spacing={1}>
                      <Grid item xs={12}>
                        <center>
                      <CardMedia 
                         image={pic} style={{height:270,width:250,marginTop:30}}
                       />
                       </center>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                          <TextField type="text" style={{width:300,}} helperText="Please enter username" label="Username"  id="outlined-size-small" variant="standard" backgroundColor="#002984" size="small" name="username" value={username}
                          onChange={this.handleUsernameChange}
                          validators={["isName"]}
                          errorMessages={["enter a valid user name"]}
                          />
                        </FormControl>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                          <TextValidator type="text" style={{width:300,}} helperText="Please enter e-mail address" label="Email Address"  id="outlined-size-small" variant="standard" size="small" name="password" value={email}
                           onChange={this.handleEmailChange}
                           validators={["isEmail"]}
                           errorMessages={["enter a valid email"]}
                           />
                        </FormControl>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                          <TextField type="password" style={{width:300,}} helperText="Please enter password" label="Password"  id="outlined-size-small" variant="standard" backgroundColor="#002984" size="small" name="username" value={password}
                            onChange={this.handlePasswordChange}
                            />
                        </FormControl>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                          <TextField type="password" style={{width:300,}} helperText="Please enter the password again " label="Confirm Password"  id="outlined-size-small" variant="standard" backgroundColor="#002984" size="small" name="username" value={confirmpassword}
                            onChange={this.handleConfirmPasswordChange}
                            />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12}>
                        <FormControl>
                          <Button style={{borderRadius:20,backgroundColor:'#A0522D',width:200,height:45,borderColor: '#fff',}}>
                            <span><b>SignUp</b></span>
                          </Button>
                        </FormControl>
                      </Grid>
                  </Grid>
                  
                    <div>
                      <Typography color='error' variant="overline" display="block" gutterBottom>
                          <strong>{this.state.message}</strong>
                      </Typography>
                    </div>
                  
                </ValidatorForm>
                </Paper>
              </CardContent>
        </Card>
        </center>
        </Grid>
        <Grid item xs={5}/>
      </Grid>
      </Paper>
      </div>
    );
  }
}